from .core import WidgetApp,DesktopWidget,set_default_color,get_default_color
from .clock import AnalogClockWidget
from .stopwatch import StopwatchWidget
from .water import WaterWidget
from .orb_bouncer import OrbControllerWidget,BouncingOrb
from .extras import CalendarWidget,ShortcutWidget,NoteWidget,FocusOrbWidget,MagicOrbWidget,CombinedWidget,CustomWidget,ScriptWidget
__version__='0.8.0'
__all__=['WidgetApp','DesktopWidget','AnalogClockWidget','StopwatchWidget','WaterWidget','OrbControllerWidget','BouncingOrb','CalendarWidget','ShortcutWidget','NoteWidget','FocusOrbWidget','MagicOrbWidget','CombinedWidget','CustomWidget','ScriptWidget','set_default_color','get_default_color']

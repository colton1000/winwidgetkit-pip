from .core import DesktopWidget

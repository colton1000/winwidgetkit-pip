from .core import WidgetApp
